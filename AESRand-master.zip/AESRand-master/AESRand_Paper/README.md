While the other directories were made for testing or prototyping, this directory will be the final
version for the expected paper. 

The hope is for this single directory to be portable across ARM, x86, and Power9

